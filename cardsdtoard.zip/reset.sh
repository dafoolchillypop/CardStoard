#!/bin/bash

docker-compose down

sleep 3

docker-compose build

sleep 3

docker-compose up
